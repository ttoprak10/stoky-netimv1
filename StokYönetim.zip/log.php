<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Sadece admin erişebilir
if ($_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Filtreleme parametreleri
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$action_type = isset($_GET['action_type']) ? $_GET['action_type'] : '';

// SQL sorgusu oluşturma
$sql = "SELECT l.*, u.username, u.full_name 
        FROM activity_logs l
        JOIN users u ON l.user_id = u.id
        WHERE DATE(l.created_at) BETWEEN ? AND ?";

$params = [$start_date, $end_date];
$types = "ss";

if ($user_id > 0) {
    $sql .= " AND l.user_id = ?";
    $params[] = $user_id;
    $types .= "i";
}

if ($action_type != '') {
    $sql .= " AND l.action_type = ?";
    $params[] = $action_type;
    $types .= "s";
}

$sql .= " ORDER BY l.created_at DESC";

// Sorguyu hazırlama ve çalıştırma
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Hata ayıklama bilgileri
echo "<!-- Debug bilgileri:
Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "
SQL sorgusu: " . $sql . "
Parametreler: " . implode(', ', $params) . "
Tip string: " . $types . "
Hata (varsa): " . $conn->error . "
Sonuç sayısı: " . ($result ? $result->num_rows : '0') . "
-->";

// Kullanıcı listesini al
$users_sql = "SELECT id, username, full_name FROM users ORDER BY username";
$users = $conn->query($users_sql);

// DataTables için veri hazırlığı
$logs_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $logs_data[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sistem Logları - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="vendor/daterangepicker/daterangepicker.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Sistem Logları</h1>
                    <p class="mb-4">Sistemde yapılan tüm işlemlerin kayıtlarını görüntüleyebilirsiniz.</p>

                    <!-- Filtreleme Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Filtrele</h6>
                        </div>
                        <div class="card-body">
                            <form method="get" class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="daterange">Tarih Aralığı</label>
                                    <input type="text" class="form-control" id="daterange" name="daterange" value="<?php echo date('d/m/Y', strtotime($start_date)) . ' - ' . date('d/m/Y', strtotime($end_date)); ?>">
                                    <input type="hidden" name="start_date" id="start_date" value="<?php echo $start_date; ?>">
                                    <input type="hidden" name="end_date" id="end_date" value="<?php echo $end_date; ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="user_id">Kullanıcı</label>
                                    <select class="form-control" id="user_id" name="user_id">
                                        <option value="0">Tümü</option>
                                        <?php while ($user = $users->fetch_assoc()): ?>
                                        <option value="<?php echo $user['id']; ?>" <?php echo $user_id == $user['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($user['username'] . ' (' . $user['full_name'] . ')'); ?>
                                        </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="action_type">İşlem Tipi</label>
                                    <select class="form-control" id="action_type" name="action_type">
                                        <option value="">Tümü</option>
                                        <option value="login" <?php echo $action_type == 'login' ? 'selected' : ''; ?>>Giriş</option>
                                        <option value="logout" <?php echo $action_type == 'logout' ? 'selected' : ''; ?>>Çıkış</option>
                                        <option value="stock_add" <?php echo $action_type == 'stock_add' ? 'selected' : ''; ?>>Stok Girişi</option>
                                        <option value="stock_remove" <?php echo $action_type == 'stock_remove' ? 'selected' : ''; ?>>Stok Çıkışı</option>
                                        <option value="material_add" <?php echo $action_type == 'material_add' ? 'selected' : ''; ?>>Malzeme Ekleme</option>
                                        <option value="material_edit" <?php echo $action_type == 'material_edit' ? 'selected' : ''; ?>>Malzeme Düzenleme</option>
                                        <option value="material_delete" <?php echo $action_type == 'material_delete' ? 'selected' : ''; ?>>Malzeme Silme</option>
                                        <option value="warehouse_add" <?php echo $action_type == 'warehouse_add' ? 'selected' : ''; ?>>Ambar Ekleme</option>
                                        <option value="warehouse_edit" <?php echo $action_type == 'warehouse_edit' ? 'selected' : ''; ?>>Ambar Düzenleme</option>
                                        <option value="warehouse_delete" <?php echo $action_type == 'warehouse_delete' ? 'selected' : ''; ?>>Ambar Silme</option>
                                        <option value="user_add" <?php echo $action_type == 'user_add' ? 'selected' : ''; ?>>Kullanıcı Ekleme</option>
                                        <option value="user_edit" <?php echo $action_type == 'user_edit' ? 'selected' : ''; ?>>Kullanıcı Düzenleme</option>
                                        <option value="user_delete" <?php echo $action_type == 'user_delete' ? 'selected' : ''; ?>>Kullanıcı Silme</option>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label>&nbsp;</label>
                                    <div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-filter fa-sm"></i> Filtrele
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Log Tablosu -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Log Kayıtları</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Kullanıcı</th>
                                            <th>İşlem</th>
                                            <th>Detay</th>
                                            <th>IP Adresi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($logs_data as $log): ?>
                                        <tr>
                                            <td><?php echo date('d.m.Y H:i:s', strtotime($log['created_at'])); ?></td>
                                            <td><?php echo htmlspecialchars($log['full_name'] . ' (' . $log['username'] . ')'); ?></td>
                                            <td>
                                                <?php
                                                $action_labels = [
                                                    'login' => '<span class="badge badge-success">Giriş</span>',
                                                    'logout' => '<span class="badge badge-secondary">Çıkış</span>',
                                                    'stock_add' => '<span class="badge badge-primary">Stok Girişi</span>',
                                                    'stock_remove' => '<span class="badge badge-warning">Stok Çıkışı</span>',
                                                    'material_add' => '<span class="badge badge-info">Malzeme Ekleme</span>',
                                                    'material_edit' => '<span class="badge badge-info">Malzeme Düzenleme</span>',
                                                    'material_delete' => '<span class="badge badge-danger">Malzeme Silme</span>',
                                                    'warehouse_add' => '<span class="badge badge-info">Ambar Ekleme</span>',
                                                    'warehouse_edit' => '<span class="badge badge-info">Ambar Düzenleme</span>',
                                                    'warehouse_delete' => '<span class="badge badge-danger">Ambar Silme</span>',
                                                    'user_add' => '<span class="badge badge-info">Kullanıcı Ekleme</span>',
                                                    'user_edit' => '<span class="badge badge-info">Kullanıcı Düzenleme</span>',
                                                    'user_delete' => '<span class="badge badge-danger">Kullanıcı Silme</span>'
                                                ];
                                                echo $action_labels[$log['action_type']] ?? $log['action_type'];
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($log['details']); ?></td>
                                            <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include 'includes/logout_modal.php'; ?>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="vendor/moment/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

    <script>
    $(document).ready(function() {
        // DataTables başlatma
        $('#dataTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json'
            },
            order: [[0, 'desc']],
            pageLength: 25
        });

        // DateRangePicker başlatma
        $('#daterange').daterangepicker({
            locale: {
                format: 'DD/MM/YYYY',
                separator: ' - ',
                applyLabel: 'Uygula',
                cancelLabel: 'İptal',
                fromLabel: 'Dan',
                toLabel: 'a',
                customRangeLabel: 'Özel',
                weekLabel: 'H',
                daysOfWeek: ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'],
                monthNames: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
                firstDay: 1
            },
            startDate: moment(<?php echo json_encode($start_date); ?>).format('DD/MM/YYYY'),
            endDate: moment(<?php echo json_encode($end_date); ?>).format('DD/MM/YYYY')
        }, function(start, end) {
            $('#start_date').val(start.format('YYYY-MM-DD'));
            $('#end_date').val(end.format('YYYY-MM-DD'));
        });
    });
    </script>
</body>
</html> 
<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

if (!isset($_GET['id'])) {
    header("Location: warehouses.php");
    exit();
}

$warehouse_id = (int)$_GET['id'];

// Ambar bilgilerini getir
$sql = "SELECT * FROM warehouses WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $warehouse_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: warehouses.php");
    exit();
}

$warehouse = $result->fetch_assoc();
$stmt->close();

// Personel atama işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_staff'])) {
    $user_id = (int)$_POST['user_id'];
    
    // Önce bu kullanıcının bu ambara zaten atanıp atanmadığını kontrol et
    $check_sql = "SELECT id FROM warehouse_staff WHERE warehouse_id = ? AND user_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $warehouse_id, $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $error = "Bu personel zaten bu ambara atanmış.";
    } else {
        // Personeli ambara ata
        $sql = "INSERT INTO warehouse_staff (warehouse_id, user_id, assigned_by, assigned_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $warehouse_id, $user_id, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $success = "Personel başarıyla atandı.";
        } else {
            $error = "Personel atanırken bir hata oluştu: " . $conn->error;
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// Personel silme işlemi
if (isset($_GET['remove'])) {
    $user_id = (int)$_GET['remove'];
    
    $sql = "DELETE FROM warehouse_staff WHERE warehouse_id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $warehouse_id, $user_id);
    
    if ($stmt->execute()) {
        $success = "Personel başarıyla kaldırıldı.";
    } else {
        $error = "Personel kaldırılırken bir hata oluştu.";
    }
    $stmt->close();
}

// Mevcut görevli personeli getir
$sql = "SELECT u.* 
        FROM users u 
        JOIN warehouse_staff ws ON u.id = ws.user_id 
        WHERE ws.warehouse_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $warehouse_id);
$stmt->execute();
$current_staff = $stmt->get_result();
$stmt->close();

// Atanabilecek personeli getir (mevcut görevliler hariç)
$sql = "SELECT u.* 
        FROM users u 
        WHERE u.status = 1 
        AND u.id NOT IN (
            SELECT user_id 
            FROM warehouse_staff 
            WHERE warehouse_id = ?
        )
        ORDER BY u.full_name";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $warehouse_id);
$stmt->execute();
$available_staff = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Personel Ata - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Personel Ata</h1>
                    <p class="mb-4"><?php echo htmlspecialchars($warehouse['name']); ?> ambarına personel atama işlemleri</p>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <!-- Personel Atama Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Yeni Personel Ata</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" class="form-inline">
                                <div class="form-group mx-sm-3 mb-2">
                                    <select name="user_id" class="form-control" required>
                                        <option value="">Personel Seçin</option>
                                        <?php while ($user = $available_staff->fetch_assoc()): ?>
                                            <option value="<?php echo $user['id']; ?>">
                                                <?php echo htmlspecialchars($user['full_name']); ?> 
                                                (<?php echo htmlspecialchars($user['username']); ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <button type="submit" name="assign_staff" class="btn btn-primary mb-2">Personel Ata</button>
                            </form>
                        </div>
                    </div>

                    <!-- Mevcut Personel Listesi -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Mevcut Personel</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Ad Soyad</th>
                                            <th>Kullanıcı Adı</th>
                                            <th>E-posta</th>
                                            <th>Rol</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($staff = $current_staff->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($staff['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($staff['username']); ?></td>
                                            <td><?php echo htmlspecialchars($staff['email']); ?></td>
                                            <td>
                                                <?php
                                                switch ($staff['role']) {
                                                    case 'admin':
                                                        echo 'Yönetici';
                                                        break;
                                                    case 'personel':
                                                        echo 'Personel';
                                                        break;
                                                    case 'depo_gorevlisi':
                                                        echo 'Depo Görevlisi';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <form method="GET" action="" style="display: inline;">
                                                    <input type="hidden" name="remove" value="<?php echo $staff['id']; ?>">
                                                    <button type="submit" name="remove" class="btn btn-danger btn-sm" onclick="return confirm('Bu personeli kaldırmak istediğinize emin misiniz?')">
                                                        <i class="fas fa-user-minus"></i> Kaldır
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
                }
            });
        });
    </script>
</body>
</html> 
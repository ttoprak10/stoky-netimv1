/**
 * Sistem log kaydı oluşturur
 * 
 * @param string $action_type İşlem tipi
 * @param string $details İşlem detayları
 * @return bool İşlem başarılı ise true, değilse false döner
 */
function createLog($action_type, $details = '') {
    global $conn;
    
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    $user_id = $_SESSION['user_id'];
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action_type, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $action_type, $details, $ip_address);
    
    return $stmt->execute();
} 
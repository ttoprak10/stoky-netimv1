<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Ambar ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_warehouse'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO warehouses (name, location, description) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $location, $description);
    
    if ($stmt->execute()) {
        $success = "Ambar başarıyla eklendi.";
    } else {
        $error = "Ambar eklenirken bir hata oluştu.";
    }
    $stmt->close();
}

// Ambar silme işlemi
if (isset($_GET['delete']) && $_SESSION['role'] === 'admin') {
    $id = (int)$_GET['delete'];
    
    // Önce ambar görevlilerini sil
    $sql = "DELETE FROM warehouse_staff WHERE warehouse_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    
    // Sonra ambarı sil
    $sql = "DELETE FROM warehouses WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $success = "Ambar başarıyla silindi.";
    } else {
        $error = "Ambar silinirken bir hata oluştu.";
    }
    $stmt->close();
}

// Ambarları listele
$sql = "SELECT w.*, GROUP_CONCAT(CONCAT(u.full_name, ' (', u.username, ')') SEPARATOR ', ') as staff 
        FROM warehouses w 
        LEFT JOIN warehouse_staff ws ON w.id = ws.warehouse_id 
        LEFT JOIN users u ON ws.user_id = u.id 
        GROUP BY w.id 
        ORDER BY w.name";
$result = $conn->query($sql);

// Hata ayıklama
echo "<!-- Debug bilgileri:
Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "
SQL sorgusu: " . $sql . "
Hata (varsa): " . $conn->error . "
Sonuç: " . ($result ? "Başarılı" : "Başarısız") . "
Kayıt sayısı: " . ($result ? $result->num_rows : "0") . "
-->";

if (!$result) {
    die("Veritabanı hatası: " . $conn->error);
}

// Sonuç kümesinde kayıt var mı kontrol et
if ($result->num_rows === 0) {
    $warning = "Henüz hiç ambar eklenmemiş.";
}

// DataTables için veri hazırlığı
$warehouses_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $warehouses_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Ambarlar - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Ambarlar</h1>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <!-- Ambar Ekleme Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Yeni Ambar Ekle</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Ambar Adı</label>
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Konum</label>
                                        <input type="text" class="form-control" name="location" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Açıklama</label>
                                    <textarea class="form-control" name="description" rows="3"></textarea>
                                </div>
                                <button type="submit" name="add_warehouse" class="btn btn-primary">Ambar Ekle</button>
                            </form>
                        </div>
                    </div>

                    <!-- Ambar Listesi Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Ambar Listesi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Ambar Adı</th>
                                            <th>Konum</th>
                                            <th>Açıklama</th>
                                            <th>Görevli Personel</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($warehouses_data as $row): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['location']); ?></td>
                                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                                            <td><?php echo $row['staff'] ? htmlspecialchars($row['staff']) : '<em>Görevli personel yok</em>'; ?></td>
                                            <td>
                                                <a href="assign_staff.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-user-plus"></i>
                                                </a>
                                                <a href="edit_warehouse.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                                <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu ambarı silmek istediğinize emin misiniz? Bu işlem geri alınamaz!')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
                }
            });
        });
    </script>
</body>
</html> 
<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-warehouse"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Stok Takip</div>
    </a>

    <hr class="sidebar-divider my-0">

    <li class="nav-item">
        <a class="nav-link" href="index.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Gösterge Paneli</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Stok İşlemleri
    </div>

    <li class="nav-item">
        <a class="nav-link" href="materials.php">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Malzemeler</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="stock_operations.php">
            <i class="fas fa-fw fa-dolly"></i>
            <span>Stok İşlemleri</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="stock_movements.php">
            <i class="fas fa-fw fa-exchange-alt"></i>
            <span>Stok Hareketleri</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="warehouses.php">
            <i class="fas fa-fw fa-warehouse"></i>
            <span>Ambarlar</span>
        </a>
    </li>

    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Yönetim
    </div>

    <li class="nav-item">
        <a class="nav-link" href="users.php">
            <i class="fas fa-fw fa-users"></i>
            <span>Kullanıcılar</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="log.php">
            <i class="fas fa-fw fa-history"></i>
            <span>Sistem Logları</span>
        </a>
    </li>
    <?php endif; ?>

    <hr class="sidebar-divider">

    <li class="nav-item">
        <a class="nav-link" href="chat.php">
            <i class="fas fa-fw fa-comments"></i>
            <span>Mesajlar</span>
        </a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<!-- End of Sidebar --> 
<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

if (!isset($_GET['id'])) {
    header("Location: warehouses.php");
    exit();
}

$id = (int)$_GET['id'];

// Ambar güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_warehouse'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "UPDATE warehouses SET name = ?, location = ?, description = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $location, $description, $id);
    
    if ($stmt->execute()) {
        $success = "Ambar başarıyla güncellendi.";
    } else {
        $error = "Ambar güncellenirken bir hata oluştu.";
    }
    $stmt->close();
}

// Ambar bilgilerini getir
$sql = "SELECT * FROM warehouses WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: warehouses.php");
    exit();
}

$warehouse = $result->fetch_assoc();
$stmt->close();

// Ambardaki malzemeleri getir
$sql = "SELECT m.name, m.unit, s.quantity, m.min_stock 
        FROM stock s 
        JOIN materials m ON s.material_id = m.id 
        WHERE s.warehouse_id = ? 
        ORDER BY m.name";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$materials = $stmt->get_result();
$stmt->close();

// Ambar görevlilerini getir
$sql = "SELECT u.* 
        FROM users u 
        JOIN warehouse_staff ws ON u.id = ws.user_id 
        WHERE ws.warehouse_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$staff = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Ambar Düzenle - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Ambar Düzenle</h1>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Ambar Bilgileri</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Ambar Adı</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($warehouse['name']); ?>" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Konum</label>
                                        <input type="text" class="form-control" name="location" value="<?php echo htmlspecialchars($warehouse['location']); ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Açıklama</label>
                                    <textarea class="form-control" name="description" rows="3"><?php echo htmlspecialchars($warehouse['description']); ?></textarea>
                                </div>
                                <button type="submit" name="edit_warehouse" class="btn btn-primary">Değişiklikleri Kaydet</button>
                                <a href="warehouses.php" class="btn btn-secondary">İptal</a>
                            </form>
                        </div>
                    </div>

                    <!-- Görevli Personel Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Görevli Personel</h6>
                            <a href="assign_staff.php?id=<?php echo $id; ?>" class="btn btn-success btn-sm">
                                <i class="fas fa-user-plus"></i> Personel Ata
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Ad Soyad</th>
                                            <th>Kullanıcı Adı</th>
                                            <th>E-posta</th>
                                            <th>Rol</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $staff->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                                            <td>
                                                <?php
                                                switch ($row['role']) {
                                                    case 'admin':
                                                        echo 'Yönetici';
                                                        break;
                                                    case 'personel':
                                                        echo 'Personel';
                                                        break;
                                                    case 'depo_gorevlisi':
                                                        echo 'Depo Görevlisi';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Stok Durumu Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Stok Durumu</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Malzeme</th>
                                            <th>Birim</th>
                                            <th>Miktar</th>
                                            <th>Minimum Stok</th>
                                            <th>Durum</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $materials->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['unit']); ?></td>
                                            <td><?php echo $row['quantity']; ?></td>
                                            <td><?php echo $row['min_stock']; ?></td>
                                            <td>
                                                <?php if ($row['quantity'] <= $row['min_stock']): ?>
                                                    <span class="badge badge-danger">Kritik Stok</span>
                                                <?php else: ?>
                                                    <span class="badge badge-success">Normal</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
                }
            });
        });
    </script>
</body>
</html> 
<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Oturum kontrolü
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: materials.php");
    exit();
}

$id = (int)$_GET['id'];

// Malzeme güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_material'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $unit = mysqli_real_escape_string($conn, $_POST['unit']);
    $min_stock = (int)$_POST['min_stock'];

    $sql = "UPDATE materials SET name = ?, description = ?, unit = ?, min_stock = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $name, $description, $unit, $min_stock, $id);
    
    if ($stmt->execute()) {
        $success = "Malzeme başarıyla güncellendi.";
    } else {
        $error = "Malzeme güncellenirken bir hata oluştu.";
    }
    $stmt->close();
}

// Malzeme bilgilerini getir
$sql = "SELECT * FROM materials WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: materials.php");
    exit();
}

$material = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Malzeme Düzenle - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Malzeme Düzenle</h1>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Malzeme Bilgileri</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Malzeme Adı</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($material['name']); ?>" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label>Birim</label>
                                        <input type="text" class="form-control" name="unit" value="<?php echo htmlspecialchars($material['unit']); ?>" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label>Minimum Stok</label>
                                        <input type="number" class="form-control" name="min_stock" value="<?php echo $material['min_stock']; ?>" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Açıklama</label>
                                    <textarea class="form-control" name="description" rows="3"><?php echo htmlspecialchars($material['description']); ?></textarea>
                                </div>
                                <button type="submit" name="edit_material" class="btn btn-primary">Değişiklikleri Kaydet</button>
                                <a href="materials.php" class="btn btn-secondary">İptal</a>
                            </form>
                        </div>
                    </div>

                    <!-- Stok Durumu Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Stok Durumu</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Ambar</th>
                                            <th>Miktar</th>
                                            <th>Son Güncelleme</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT s.quantity, s.updated_at, w.name as warehouse_name 
                                                FROM stock s 
                                                JOIN warehouses w ON s.warehouse_id = w.id 
                                                WHERE s.material_id = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("i", $id);
                                        $stmt->execute();
                                        $result = $stmt->get_result();
                                        
                                        $total_stock = 0;
                                        while ($row = $result->fetch_assoc()) {
                                            $total_stock += $row['quantity'];
                                            echo '<tr>
                                                    <td>' . htmlspecialchars($row['warehouse_name']) . '</td>
                                                    <td>' . $row['quantity'] . '</td>
                                                    <td>' . date('d.m.Y H:i', strtotime($row['updated_at'])) . '</td>
                                                </tr>';
                                        }
                                        $stmt->close();
                                        ?>
                                        <tr class="table-info">
                                            <td><strong>Toplam</strong></td>
                                            <td colspan="2"><strong><?php echo $total_stock; ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>
</html> 
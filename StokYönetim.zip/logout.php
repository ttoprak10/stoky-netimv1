<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Log kaydı oluştur
if (isset($_SESSION['user_id'])) {
    createLog('logout', 'Kullanıcı sistemden çıkış yaptı');
}

// Oturumu sonlandır
session_destroy();

// Ana sayfaya yönlendir
header('Location: login.php');
exit;
?> 
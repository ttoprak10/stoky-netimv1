<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: index.php");
        exit();
    }
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

function getUnreadMessageCount() {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM messages 
            WHERE receiver_id = ? AND is_read = 0 AND deleted_by_receiver = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['count'];
}

function getUserFullName() {
    return isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '';
}

function logout() {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}
?> 
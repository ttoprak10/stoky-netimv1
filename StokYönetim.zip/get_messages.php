<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

header('Content-Type: application/json');

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$last_id = isset($_GET['last_id']) ? (int)$_GET['last_id'] : 0;

if ($user_id <= 0) {
    echo json_encode(['error' => 'Geçersiz kullanıcı ID']);
    exit;
}

// Mesajları getir
$sql = "SELECT m.*, u.full_name as sender_name 
        FROM messages m 
        JOIN users u ON m.sender_id = u.id 
        WHERE (m.sender_id = ? AND m.receiver_id = ?) 
           OR (m.sender_id = ? AND m.receiver_id = ?)";

if ($last_id > 0) {
    $sql .= " AND m.id > ?";
}

$sql .= " ORDER BY m.created_at ASC";

$stmt = $conn->prepare($sql);

if ($last_id > 0) {
    $stmt->bind_param("iiiii", $_SESSION['user_id'], $user_id, $user_id, $_SESSION['user_id'], $last_id);
} else {
    $stmt->bind_param("iiii", $_SESSION['user_id'], $user_id, $user_id, $_SESSION['user_id']);
}

$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'id' => $row['id'],
        'message' => htmlspecialchars($row['message']),
        'sender_id' => $row['sender_id'],
        'created_at' => date('H:i', strtotime($row['created_at']))
    ];
}

// Okunmamış mesajları okundu olarak işaretle
$update_sql = "UPDATE messages SET is_read = 1 
               WHERE receiver_id = ? AND sender_id = ? AND is_read = 0";
$update_stmt = $conn->prepare($update_sql);
$update_stmt->bind_param("ii", $_SESSION['user_id'], $user_id);
$update_stmt->execute();

echo json_encode(['messages' => $messages]); 
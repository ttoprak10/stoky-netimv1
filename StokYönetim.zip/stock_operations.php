<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Stok ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_stock'])) {
    $material_id = (int)$_POST['material_id'];
    $warehouse_id = (int)$_POST['warehouse_id'];
    $quantity = (int)$_POST['quantity'];
    $unit_price = (float)$_POST['unit_price'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $reference_no = mysqli_real_escape_string($conn, $_POST['reference_no']);
    
    // Transaction başlat
    $conn->begin_transaction();
    
    try {
        // Stok hareketini kaydet
        $sql = "INSERT INTO stock_movements (material_id, warehouse_id, movement_type, quantity, unit_price, total_price, description, reference_no, created_by) 
                VALUES (?, ?, 'giris', ?, ?, ?, ?, ?, ?)";
        $total_price = $quantity * $unit_price;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiddsis", $material_id, $warehouse_id, $quantity, $unit_price, $total_price, $description, $reference_no, $_SESSION['user_id']);
        $stmt->execute();
        
        // Stok tablosunu güncelle
        $sql = "INSERT INTO stock (material_id, warehouse_id, quantity) 
                VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $material_id, $warehouse_id, $quantity);
        $stmt->execute();
        
        $conn->commit();
        $success = "Stok başarıyla eklendi.";
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Stok eklenirken bir hata oluştu: " . $e->getMessage();
    }
}

// Stok çıkışı işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_stock'])) {
    $material_id = (int)$_POST['material_id'];
    $warehouse_id = (int)$_POST['warehouse_id'];
    $quantity = (int)$_POST['quantity'];
    $unit_price = (float)$_POST['unit_price'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $reference_no = mysqli_real_escape_string($conn, $_POST['reference_no']);
    
    // Transaction başlat
    $conn->begin_transaction();
    
    try {
        // Stok miktarını kontrol et
        $sql = "SELECT quantity FROM stock WHERE material_id = ? AND warehouse_id = ? AND quantity >= ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $material_id, $warehouse_id, $quantity);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Yeterli stok bulunmuyor!");
        }
        
        // Stok hareketini kaydet
        $sql = "INSERT INTO stock_movements (material_id, warehouse_id, movement_type, quantity, unit_price, total_price, description, reference_no, created_by) 
                VALUES (?, ?, 'cikis', ?, ?, ?, ?, ?, ?)";
        $total_price = $quantity * $unit_price;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiddsis", $material_id, $warehouse_id, $quantity, $unit_price, $total_price, $description, $reference_no, $_SESSION['user_id']);
        $stmt->execute();
        
        // Stok tablosunu güncelle
        $sql = "UPDATE stock SET quantity = quantity - ? WHERE material_id = ? AND warehouse_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iii", $quantity, $material_id, $warehouse_id);
        $stmt->execute();
        
        $conn->commit();
        $success = "Stok çıkışı başarıyla yapıldı.";
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Stok çıkışı yapılırken bir hata oluştu: " . $e->getMessage();
    }
}

// Malzeme listesini al
$sql = "SELECT m.*, COALESCE(SUM(s.quantity), 0) as total_stock 
        FROM materials m 
        LEFT JOIN stock s ON m.id = s.material_id 
        GROUP BY m.id 
        ORDER BY m.name";
$materials = $conn->query($sql);

// Ambar listesini al
$sql = "SELECT w.*, COALESCE(COUNT(DISTINCT s.material_id), 0) as unique_materials,
        COALESCE(SUM(s.quantity), 0) as total_items
        FROM warehouses w
        LEFT JOIN stock s ON w.id = s.warehouse_id
        GROUP BY w.id
        ORDER BY w.name";
$warehouses = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Stok İşlemleri - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Stok İşlemleri</h1>
                    <p class="mb-4">Stok giriş ve çıkış işlemlerini bu sayfadan yapabilirsiniz.</p>

                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <!-- Stok Giriş Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Stok Girişi</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" id="addStockForm">
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <label for="material_id">Malzeme</label>
                                        <select class="form-control" id="material_id" name="material_id" required>
                                            <option value="">Seçiniz</option>
                                            <?php while ($material = $materials->fetch_assoc()): ?>
                                            <option value="<?php echo $material['id']; ?>" data-unit="<?php echo htmlspecialchars($material['unit']); ?>">
                                                <?php echo htmlspecialchars($material['name']); ?> 
                                                (Mevcut: <?php echo number_format($material['total_stock']); ?> <?php echo htmlspecialchars($material['unit']); ?>)
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="warehouse_id">Ambar</label>
                                        <select class="form-control" id="warehouse_id" name="warehouse_id" required>
                                            <option value="">Seçiniz</option>
                                            <?php while ($warehouse = $warehouses->fetch_assoc()): ?>
                                            <option value="<?php echo $warehouse['id']; ?>">
                                                <?php echo htmlspecialchars($warehouse['name']); ?>
                                                (<?php echo number_format($warehouse['unique_materials']); ?> malzeme, 
                                                <?php echo number_format($warehouse['total_items']); ?> adet)
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="reference_no">Referans No</label>
                                        <input type="text" class="form-control" id="reference_no" name="reference_no" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="quantity">Miktar</label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="unit_display">Birim</label>
                                        <input type="text" class="form-control" id="unit_display" readonly>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="unit_price">Birim Fiyat (₺)</label>
                                        <input type="number" class="form-control" id="unit_price" name="unit_price" min="0" step="0.01" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="total_price">Toplam Tutar (₺)</label>
                                        <input type="text" class="form-control" id="total_price" readonly>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">Açıklama</label>
                                    <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                                </div>
                                <button type="submit" name="add_stock" class="btn btn-success">
                                    <i class="fas fa-plus-circle"></i> Stok Girişi Yap
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Stok Çıkış Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Stok Çıkışı</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" id="removeStockForm">
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        <label for="material_id_out">Malzeme</label>
                                        <select class="form-control" id="material_id_out" name="material_id" required>
                                            <option value="">Seçiniz</option>
                                            <?php 
                                            $materials->data_seek(0);
                                            while ($material = $materials->fetch_assoc()): 
                                            ?>
                                            <option value="<?php echo $material['id']; ?>" data-unit="<?php echo htmlspecialchars($material['unit']); ?>">
                                                <?php echo htmlspecialchars($material['name']); ?> 
                                                (Mevcut: <?php echo number_format($material['total_stock']); ?> <?php echo htmlspecialchars($material['unit']); ?>)
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="warehouse_id_out">Ambar</label>
                                        <select class="form-control" id="warehouse_id_out" name="warehouse_id" required>
                                            <option value="">Seçiniz</option>
                                            <?php 
                                            $warehouses->data_seek(0);
                                            while ($warehouse = $warehouses->fetch_assoc()): 
                                            ?>
                                            <option value="<?php echo $warehouse['id']; ?>">
                                                <?php echo htmlspecialchars($warehouse['name']); ?>
                                                (<?php echo number_format($warehouse['unique_materials']); ?> malzeme, 
                                                <?php echo number_format($warehouse['total_items']); ?> adet)
                                            </option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="reference_no_out">Referans No</label>
                                        <input type="text" class="form-control" id="reference_no_out" name="reference_no" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-3">
                                        <label for="quantity_out">Miktar</label>
                                        <input type="number" class="form-control" id="quantity_out" name="quantity" min="1" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="unit_display_out">Birim</label>
                                        <input type="text" class="form-control" id="unit_display_out" readonly>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="unit_price_out">Birim Fiyat (₺)</label>
                                        <input type="number" class="form-control" id="unit_price_out" name="unit_price" min="0" step="0.01" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label for="total_price_out">Toplam Tutar (₺)</label>
                                        <input type="text" class="form-control" id="total_price_out" readonly>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description_out">Açıklama</label>
                                    <textarea class="form-control" id="description_out" name="description" rows="2"></textarea>
                                </div>
                                <button type="submit" name="remove_stock" class="btn btn-danger">
                                    <i class="fas fa-minus-circle"></i> Stok Çıkışı Yap
                                </button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include 'includes/logout_modal.php'; ?>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

    <script>
    $(document).ready(function() {
        // Stok giriş formu için birim ve toplam fiyat hesaplama
        $('#material_id').change(function() {
            var selectedOption = $(this).find('option:selected');
            $('#unit_display').val(selectedOption.data('unit'));
        });

        $('#quantity, #unit_price').on('input', function() {
            var quantity = $('#quantity').val();
            var unitPrice = $('#unit_price').val();
            var total = quantity * unitPrice;
            $('#total_price').val(total.toFixed(2));
        });

        // Stok çıkış formu için birim ve toplam fiyat hesaplama
        $('#material_id_out').change(function() {
            var selectedOption = $(this).find('option:selected');
            $('#unit_display_out').val(selectedOption.data('unit'));
        });

        $('#quantity_out, #unit_price_out').on('input', function() {
            var quantity = $('#quantity_out').val();
            var unitPrice = $('#unit_price_out').val();
            var total = quantity * unitPrice;
            $('#total_price_out').val(total.toFixed(2));
        });

        // Form gönderilmeden önce kontrol
        $('#addStockForm, #removeStockForm').submit(function() {
            if (!confirm('Bu işlemi gerçekleştirmek istediğinize emin misiniz?')) {
                return false;
            }
        });
    });
    </script>
</body>
</html> 
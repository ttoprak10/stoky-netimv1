<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Oturum ve admin kontrolü
requireAdmin();

// Kullanıcı ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $full_name = $_POST['full_name'];
    $role = $_POST['role'];
    
    // Önce kullanıcı adının kullanılıp kullanılmadığını kontrol et
    $check_sql = "SELECT id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $error = "Bu kullanıcı adı zaten kullanılıyor. Lütfen başka bir kullanıcı adı seçin.";
    } else {
        // Kullanıcı adı müsait, yeni kullanıcıyı ekle
        $sql = "INSERT INTO users (username, password, email, full_name, role, status, created_at) VALUES (?, ?, ?, ?, ?, 1, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $username, $password, $email, $full_name, $role);
        
        if ($stmt->execute()) {
            $success = "Kullanıcı başarıyla eklendi.";
            // Formu temizle
            unset($_POST);
        } else {
            $error = "Kullanıcı eklenirken bir hata oluştu: " . $conn->error;
        }
        $stmt->close();
    }
    $check_stmt->close();
}

// Kullanıcı silme işlemi
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    if ($id !== $_SESSION['user_id']) { // Kendini silmeyi engelle
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $success = "Kullanıcı başarıyla silindi.";
        } else {
            $error = "Kullanıcı silinirken bir hata oluştu.";
        }
        $stmt->close();
    } else {
        $error = "Kendi hesabınızı silemezsiniz.";
    }
}

// Kullanıcı durumunu değiştirme
if (isset($_GET['toggle_status'])) {
    $id = (int)$_GET['toggle_status'];
    
    if ($id !== $_SESSION['user_id']) { // Kendi durumunu değiştirmeyi engelle
        $sql = "UPDATE users SET status = NOT status WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $success = "Kullanıcı durumu başarıyla güncellendi.";
        } else {
            $error = "Kullanıcı durumu güncellenirken bir hata oluştu.";
        }
        $stmt->close();
    } else {
        $error = "Kendi hesabınızın durumunu değiştiremezsiniz.";
    }
}

// Kullanıcıları listele
$sql = "SELECT * FROM users ORDER BY username";
$result = $conn->query($sql);

// Hata ayıklama
echo "<!-- Debug bilgileri:
Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "
SQL sorgusu: " . $sql . "
Hata (varsa): " . $conn->error . "
Sonuç: " . ($result ? "Başarılı" : "Başarısız") . "
Kayıt sayısı: " . ($result ? $result->num_rows : "0") . "
-->";

if (!$result) {
    die("Veritabanı hatası: " . $conn->error);
}

// Sonuç kümesinde kayıt var mı kontrol et
if ($result->num_rows === 0) {
    $warning = "Henüz hiç kullanıcı eklenmemiş.";
}

// DataTables için veri hazırlığı
$users_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Kullanıcı Yönetimi - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Kullanıcı Yönetimi</h1>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <?php if (isset($warning)): ?>
                        <div class="alert alert-warning"><?php echo $warning; ?></div>
                    <?php endif; ?>

                    <!-- Kullanıcı Ekleme Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Yeni Kullanıcı Ekle</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Kullanıcı Adı</label>
                                        <input type="text" class="form-control" name="username" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>E-posta</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Ad Soyad</label>
                                        <input type="text" class="form-control" name="full_name" required>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Şifre</label>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Rol</label>
                                    <select class="form-control" name="role" required>
                                        <option value="admin">Yönetici</option>
                                        <option value="personel">Personel</option>
                                        <option value="depo_gorevlisi">Depo Görevlisi</option>
                                    </select>
                                </div>
                                <button type="submit" name="add_user" class="btn btn-primary">Kullanıcı Ekle</button>
                            </form>
                        </div>
                    </div>

                    <!-- Kullanıcı Listesi Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Kullanıcı Listesi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Kullanıcı Adı</th>
                                            <th>Ad Soyad</th>
                                            <th>E-posta</th>
                                            <th>Rol</th>
                                            <th>Durum</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($users_data as $row): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                                            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                                            <td>
                                                <?php
                                                switch ($row['role']) {
                                                    case 'admin':
                                                        echo 'Yönetici';
                                                        break;
                                                    case 'personel':
                                                        echo 'Personel';
                                                        break;
                                                    case 'depo_gorevlisi':
                                                        echo 'Depo Görevlisi';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($row['id'] !== $_SESSION['user_id']): ?>
                                                <a href="?toggle_status=<?php echo $row['id']; ?>" class="btn btn-sm <?php echo $row['status'] ? 'btn-success' : 'btn-danger'; ?>">
                                                    <?php echo $row['status'] ? 'Aktif' : 'Pasif'; ?>
                                                </a>
                                                <?php else: ?>
                                                <span class="badge badge-success">Aktif</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="edit_user.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if ($row['id'] !== $_SESSION['user_id']): ?>
                                                <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
                },
                "order": [[0, "desc"]],
                "pageLength": 25,
                "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "Tümü"]],
                "columnDefs": [
                    { "orderable": false, "targets": 6 }
                ]
            });
        });
    </script>
</body>
</html> 
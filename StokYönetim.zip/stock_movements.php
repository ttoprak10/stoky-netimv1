<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Excel'e aktarma işlemi
if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="stok_hareketleri_' . date('Y-m-d_H-i-s') . '.xls"');
    header('Cache-Control: max-age=0');
    
    echo '<!DOCTYPE html>';
    echo '<html lang="tr">';
    echo '<head><meta charset="UTF-8"></head>';
    echo '<body>';
    echo '<table border="1">';
    echo '<tr>';
    echo '<th>Tarih</th>';
    echo '<th>Ref No</th>';
    echo '<th>Malzeme</th>';
    echo '<th>Ambar</th>';
    echo '<th>Hareket Tipi</th>';
    echo '<th>Miktar</th>';
    echo '<th>Birim</th>';
    echo '<th>Birim Fiyat</th>';
    echo '<th>Toplam Tutar</th>';
    echo '<th>Açıklama</th>';
    echo '<th>İşlem Yapan</th>';
    echo '</tr>';
    
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . date('d.m.Y H:i', strtotime($row['created_at'])) . '</td>';
        echo '<td>' . htmlspecialchars($row['reference_no']) . '</td>';
        echo '<td>' . htmlspecialchars($row['material_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['warehouse_name']) . '</td>';
        echo '<td>' . ($row['movement_type'] == 'giris' ? 'Giriş' : 'Çıkış') . '</td>';
        echo '<td style="text-align: right">' . number_format($row['quantity']) . '</td>';
        echo '<td>' . htmlspecialchars($row['unit']) . '</td>';
        echo '<td style="text-align: right">' . number_format($row['unit_price'], 2) . '</td>';
        echo '<td style="text-align: right">' . number_format($row['total_price'], 2) . '</td>';
        echo '<td>' . htmlspecialchars($row['description']) . '</td>';
        echo '<td>' . htmlspecialchars($row['username']) . '</td>';
        echo '</tr>';
    }
    
    echo '</table>';
    echo '</body>';
    echo '</html>';
    exit;
}

// Filtreleme parametreleri
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$material_id = isset($_GET['material_id']) ? intval($_GET['material_id']) : 0;
$warehouse_id = isset($_GET['warehouse_id']) ? intval($_GET['warehouse_id']) : 0;
$movement_type = isset($_GET['movement_type']) ? $_GET['movement_type'] : '';

// SQL sorgusu oluşturma
$sql = "SELECT sm.*, m.name as material_name, m.unit, w.name as warehouse_name, u.username 
        FROM stock_movements sm
        JOIN materials m ON sm.material_id = m.id
        JOIN warehouses w ON sm.warehouse_id = w.id
        JOIN users u ON sm.created_by = u.id
        WHERE DATE(sm.created_at) BETWEEN ? AND ?";

$params = [$start_date, $end_date];
$types = "ss";

if ($material_id > 0) {
    $sql .= " AND sm.material_id = ?";
    $params[] = $material_id;
    $types .= "i";
}

if ($warehouse_id > 0) {
    $sql .= " AND sm.warehouse_id = ?";
    $params[] = $warehouse_id;
    $types .= "i";
}

if ($movement_type != '') {
    $sql .= " AND sm.movement_type = ?";
    $params[] = $movement_type;
    $types .= "s";
}

$sql .= " ORDER BY sm.created_at DESC";

// Hata ayıklama bilgileri
echo "<!-- Debug bilgileri:
Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "
SQL sorgusu: " . $sql . "
Hata (varsa): " . $conn->error . "
-->";

// Sorguyu hazırlama ve çalıştırma
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Sonuç kümesinde kayıt var mı kontrol et
if ($result->num_rows === 0) {
    $warning = "Belirtilen kriterlere uygun stok hareketi bulunamadı.";
}

// DataTables için veri hazırlığı
$movements_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $movements_data[] = $row;
    }
}

// Malzeme listesini alma
$materials_sql = "SELECT id, name FROM materials ORDER BY name";
$materials = $conn->query($materials_sql);

// Ambar listesini alma
$warehouses_sql = "SELECT id, name FROM warehouses ORDER BY name";
$warehouses = $conn->query($warehouses_sql);

// Toplam hareket sayısı
$sql = "SELECT COUNT(*) as total FROM stock_movements";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_movements = $row['total'];

// Toplam giriş tutarı
$sql = "SELECT COALESCE(SUM(total_price), 0) as total FROM stock_movements WHERE movement_type = 'giris'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_giris = $row['total'];

// Toplam çıkış tutarı
$sql = "SELECT COALESCE(SUM(total_price), 0) as total FROM stock_movements WHERE movement_type = 'cikis'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_cikis = $row['total'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Stok Hareketleri - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="vendor/daterangepicker/daterangepicker.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Stok Hareketleri</h1>
                    <p class="mb-4">Stok giriş ve çıkış hareketlerini görüntüleyebilir, filtreleyebilir ve raporlayabilirsiniz.</p>

                    <!-- İstatistik Kartları -->
                    <div class="row">
                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Toplam Hareket</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($total_movements); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Toplam Giriş Tutarı</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?php echo number_format($total_giris, 2, '.', ','); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-plus-circle fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Toplam Çıkış Tutarı</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?php echo number_format($total_cikis, 2, '.', ','); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-minus-circle fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Filtreleme Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Filtrele</h6>
                        </div>
                        <div class="card-body">
                            <form method="get" class="row">
                                <div class="col-md-3 mb-3">
                                    <label for="daterange">Tarih Aralığı</label>
                                    <input type="text" class="form-control" id="daterange" name="daterange" value="<?php echo date('d/m/Y', strtotime($start_date)) . ' - ' . date('d/m/Y', strtotime($end_date)); ?>">
                                    <input type="hidden" name="start_date" id="start_date" value="<?php echo $start_date; ?>">
                                    <input type="hidden" name="end_date" id="end_date" value="<?php echo $end_date; ?>">
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="material_id">Malzeme</label>
                                    <select class="form-control" id="material_id" name="material_id">
                                        <option value="0">Tümü</option>
                                        <?php while ($material = $materials->fetch_assoc()): ?>
                                        <option value="<?php echo $material['id']; ?>" <?php echo $material_id == $material['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($material['name']); ?>
                                        </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label for="warehouse_id">Ambar</label>
                                    <select class="form-control" id="warehouse_id" name="warehouse_id">
                                        <option value="0">Tümü</option>
                                        <?php while ($warehouse = $warehouses->fetch_assoc()): ?>
                                        <option value="<?php echo $warehouse['id']; ?>" <?php echo $warehouse_id == $warehouse['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($warehouse['name']); ?>
                                        </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label for="movement_type">Hareket Tipi</label>
                                    <select class="form-control" id="movement_type" name="movement_type">
                                        <option value="">Tümü</option>
                                        <option value="giris" <?php echo $movement_type == 'giris' ? 'selected' : ''; ?>>Giriş</option>
                                        <option value="cikis" <?php echo $movement_type == 'cikis' ? 'selected' : ''; ?>>Çıkış</option>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <label>&nbsp;</label>
                                    <div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-filter fa-sm"></i> Filtrele
                                        </button>
                                        <button type="button" class="btn btn-success" onclick="exportToExcel()">
                                            <i class="fas fa-file-excel fa-sm"></i> Excel
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Stok Hareketleri Tablosu -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Stok Hareketleri Listesi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Ref No</th>
                                            <th>Malzeme</th>
                                            <th>Ambar</th>
                                            <th>Tip</th>
                                            <th>Miktar</th>
                                            <th>Birim</th>
                                            <th>Birim Fiyat</th>
                                            <th>Toplam Tutar</th>
                                            <th>Açıklama</th>
                                            <th>İşlem Yapan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($movements_data as $row): ?>
                                        <tr>
                                            <td><?php echo date('d.m.Y H:i', strtotime($row['created_at'])); ?></td>
                                            <td><?php echo htmlspecialchars($row['reference_no']); ?></td>
                                            <td><?php echo htmlspecialchars($row['material_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['warehouse_name']); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo $row['movement_type'] == 'giris' ? 'success' : 'danger'; ?>">
                                                    <?php echo $row['movement_type'] == 'giris' ? 'Giriş' : 'Çıkış'; ?>
                                                </span>
                                            </td>
                                            <td class="text-right"><?php echo number_format($row['quantity']); ?></td>
                                            <td><?php echo htmlspecialchars($row['unit']); ?></td>
                                            <td class="text-right">₺<?php echo number_format($row['unit_price'], 2); ?></td>
                                            <td class="text-right">₺<?php echo number_format($row['total_price'], 2); ?></td>
                                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php include 'includes/logout_modal.php'; ?>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="vendor/moment/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

    <script>
    $(document).ready(function() {
        // DataTables başlatma
        $('#dataTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json'
            },
            order: [[0, 'desc']],
            pageLength: 25
        });

        // DateRangePicker başlatma
        $('#daterange').daterangepicker({
            locale: {
                format: 'DD/MM/YYYY',
                separator: ' - ',
                applyLabel: 'Uygula',
                cancelLabel: 'İptal',
                fromLabel: 'Dan',
                toLabel: 'a',
                customRangeLabel: 'Özel',
                weekLabel: 'H',
                daysOfWeek: ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'],
                monthNames: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
                firstDay: 1
            },
            startDate: moment(<?php echo json_encode($start_date); ?>).format('DD/MM/YYYY'),
            endDate: moment(<?php echo json_encode($end_date); ?>).format('DD/MM/YYYY')
        }, function(start, end) {
            $('#start_date').val(start.format('YYYY-MM-DD'));
            $('#end_date').val(end.format('YYYY-MM-DD'));
        });
    });

    // Excel'e aktarma fonksiyonu
    function exportToExcel() {
        let url = new URL(window.location.href);
        url.searchParams.append('export', 'excel');
        window.location.href = url.toString();
    }
    </script>
</body>
</html> 
<?php
require_once 'includes/config.php';

// Bağlantı testi
echo "Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "\n";

// Users tablosunu kontrol et
$sql = "SHOW TABLES LIKE 'users'";
$result = $conn->query($sql);
echo "Users tablosu mevcut mu: " . ($result->num_rows > 0 ? "Evet" : "Hayır") . "\n";

// Kullanıcıları listele
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result) {
    echo "Toplam kullanıcı sayısı: " . $result->num_rows . "\n";
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row['id'] . ", Kullanıcı adı: " . $row['username'] . ", Rol: " . $row['role'] . "\n";
    }
} else {
    echo "Sorgu hatası: " . $conn->error . "\n";
}

// Veritabanı karakter seti
$sql = "SHOW VARIABLES LIKE 'character_set%'";
$result = $conn->query($sql);
echo "\nKarakter seti ayarları:\n";
while ($row = $result->fetch_assoc()) {
    echo $row['Variable_name'] . ": " . $row['Value'] . "\n";
}
?> 
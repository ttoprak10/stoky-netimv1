<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

header('Content-Type: application/json');

$receiver_id = isset($_POST['receiver_id']) ? (int)$_POST['receiver_id'] : 0;
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($receiver_id <= 0 || empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Geçersiz parametreler']);
    exit;
}

// Mesajı veritabanına kaydet
$sql = "INSERT INTO messages (sender_id, receiver_id, message, created_at) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $_SESSION['user_id'], $receiver_id, $message);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message_id' => $stmt->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => 'Mesaj gönderilemedi']);
} 
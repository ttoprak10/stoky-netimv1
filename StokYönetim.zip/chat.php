<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Kullanıcı listesini al
$users_sql = "SELECT u.*, 
              (SELECT COUNT(*) FROM messages 
               WHERE sender_id = u.id 
               AND receiver_id = ? 
               AND is_read = 0) as unread_count,
              (SELECT MAX(created_at) FROM messages 
               WHERE (sender_id = u.id AND receiver_id = ?) 
               OR (sender_id = ? AND receiver_id = u.id)) as last_message_time
              FROM users u 
              WHERE u.id != ? AND u.status = 1 
              ORDER BY CASE WHEN last_message_time IS NULL THEN 1 ELSE 0 END, last_message_time DESC";
$stmt = $conn->prepare($users_sql);
$stmt->bind_param("iiii", $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']);
$stmt->execute();
$users = $stmt->get_result();

// Okunmamış mesaj sayılarını al
$unread_sql = "SELECT sender_id, COUNT(*) as unread_count 
               FROM messages 
               WHERE receiver_id = ? AND is_read = 0 AND deleted_by_receiver = 0
               GROUP BY sender_id";
$stmt = $conn->prepare($unread_sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$unread_result = $stmt->get_result();
$unread_counts = [];
while ($row = $unread_result->fetch_assoc()) {
    $unread_counts[$row['sender_id']] = $row['unread_count'];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Mesajlar - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        .chat-container {
            display: flex;
            height: calc(100vh - 200px);
            margin: 20px 0;
        }
        .users-list {
            width: 300px;
            border-right: 1px solid #e3e6f0;
            overflow-y: auto;
            background: #fff;
        }
        .chat-messages {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: #f8f9fc;
            margin-left: 20px;
            border-radius: 5px;
            border: 1px solid #e3e6f0;
        }
        .messages-container {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        .message-input {
            padding: 20px;
            background: #fff;
            border-top: 1px solid #e3e6f0;
        }
        .user-item {
            padding: 15px;
            border-bottom: 1px solid #e3e6f0;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .user-item:hover {
            background-color: #f8f9fc;
        }
        .user-item.active {
            background-color: #4e73df;
            color: #fff;
        }
        .message {
            margin-bottom: 15px;
            max-width: 80%;
        }
        .message.sent {
            margin-left: auto;
            background-color: #4e73df;
            color: #fff;
            padding: 10px 15px;
            border-radius: 15px 15px 0 15px;
        }
        .message.received {
            margin-right: auto;
            background-color: #e3e6f0;
            padding: 10px 15px;
            border-radius: 15px 15px 15px 0;
        }
        .message-time {
            font-size: 0.75rem;
            margin-top: 5px;
            opacity: 0.7;
        }
        .unread-count {
            background-color: #e74a3b;
            color: #fff;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 12px;
            float: right;
        }
        .chat-header {
            padding: 15px 20px;
            background: #fff;
            border-bottom: 1px solid #e3e6f0;
            font-weight: bold;
        }
        .no-messages {
            text-align: center;
            margin-top: 50px;
            color: #858796;
        }
    </style>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Mesajlar</h1>
                    
                    <div class="chat-container">
                        <!-- Kullanıcılar Listesi -->
                        <div class="users-list">
                            <div class="list-group">
                                <?php
                                while ($user = $users->fetch_assoc()):
                                ?>
                                <div class="user-item" onclick="loadChat(<?php echo $user['id']; ?>)">
                                    <?php echo htmlspecialchars($user['full_name']); ?>
                                    <?php if ($user['unread_count'] > 0): ?>
                                    <span class="unread-count"><?php echo $user['unread_count']; ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php endwhile; ?>
                            </div>
                        </div>
                        
                        <!-- Mesajlaşma Alanı -->
                        <div class="chat-messages">
                            <div class="chat-header" id="chat-header">
                                Bir kullanıcı seçin
                            </div>
                            <div class="messages-container" id="messages">
                                <div class="no-messages">
                                    <i class="fas fa-comments fa-3x mb-3"></i>
                                    <p>Mesajlarınız burada görünecek</p>
                                </div>
                            </div>
                            <div class="message-input">
                                <form id="message-form" style="display: none;">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="message-text" placeholder="Mesajınızı yazın...">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fas fa-paper-plane"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    
    <script>
    let currentUserId = null;
    let lastMessageId = 0;

    function loadChat(userId) {
        currentUserId = userId;
        lastMessageId = 0;
        
        $('.user-item').removeClass('active');
        $(`.user-item:contains("${userId}")`).addClass('active');
        
        // Kullanıcı adını başlığa ekle
        const userName = $(`.user-item:contains("${userId}")`).clone()
            .children().remove().end()
            .text().trim();
        $('#chat-header').text(userName);
        
        // Mesaj formunu göster
        $('#message-form').show();
        
        // Mesaj alanını temizle ve yükleniyor mesajını göster
        $('#messages').html(`
            <div class="text-center p-3">
                <i class="fas fa-spinner fa-spin"></i> Mesajlar yükleniyor...
            </div>
        `);
        
        // Mesajları yükle
        loadMessages();
    }

    function loadMessages() {
        if (!currentUserId) return;
        
        $.get('get_messages.php', { user_id: currentUserId, last_id: lastMessageId }, function(data) {
            // İlk yükleme
            if (lastMessageId === 0) {
                $('#messages').empty();
            }
            
            if (data.messages && data.messages.length > 0) {
                let html = '';
                data.messages.forEach(function(message) {
                    // Mesaj zaten eklenmiş mi kontrol et
                    if ($(`#message-${message.id}`).length === 0) {
                        const messageClass = message.sender_id == <?php echo $_SESSION['user_id']; ?> ? 'sent' : 'received';
                        html += `
                            <div id="message-${message.id}" class="message ${messageClass}">
                                <div class="message-content">${message.message}</div>
                                <div class="message-time">${message.created_at}</div>
                            </div>
                        `;
                        lastMessageId = Math.max(lastMessageId, message.id);
                    }
                });
                
                if (html) {
                    if ($('#messages').find('.message').length === 0) {
                        $('#messages').html(html);
                    } else {
                        $('#messages').append(html);
                    }
                    
                    // Scroll to bottom
                    const messagesContainer = document.getElementById('messages');
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }
            } else if ($('#messages').find('.message').length === 0) {
                // Hiç mesaj yoksa
                $('#messages').html(`
                    <div class="no-messages">
                        <i class="fas fa-comments fa-3x mb-3"></i>
                        <p>Henüz mesaj yok</p>
                    </div>
                `);
            }
        });
    }

    // Mesaj gönderme
    $('#message-form').on('submit', function(e) {
        e.preventDefault();
        
        const message = $('#message-text').val().trim();
        if (!message || !currentUserId) return;
        
        // Mesaj gönderme butonunu devre dışı bırak
        const submitButton = $(this).find('button[type="submit"]');
        submitButton.prop('disabled', true);
        
        $.post('send_message.php', {
            receiver_id: currentUserId,
            message: message
        }, function(response) {
            if (response.success) {
                $('#message-text').val('');
                // Yeni mesajı hemen göster
                const html = `
                    <div id="message-${response.message_id}" class="message sent">
                        <div class="message-content">${message}</div>
                        <div class="message-time">${new Date().toLocaleTimeString('tr-TR', {hour: '2-digit', minute:'2-digit'})}</div>
                    </div>
                `;
                $('#messages').append(html);
                
                // Scroll to bottom
                const messagesContainer = document.getElementById('messages');
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
                
                // Son mesaj ID'sini güncelle
                lastMessageId = response.message_id;
            } else {
                alert('Mesaj gönderilemedi. Lütfen tekrar deneyin.');
            }
            // Mesaj gönderme butonunu tekrar aktif et
            submitButton.prop('disabled', false);
        }).fail(function() {
            alert('Mesaj gönderilirken bir hata oluştu. Lütfen tekrar deneyin.');
            submitButton.prop('disabled', false);
        });
    });

    // Her 5 saniyede bir yeni mesajları kontrol et
    setInterval(loadMessages, 5000);
    </script>
</body>
</html> 
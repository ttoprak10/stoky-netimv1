<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <div class="input-group">
            <input type="text" class="form-control bg-light border-0 small" placeholder="Ara..." aria-label="Search" aria-describedby="basic-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                    <i class="fas fa-search fa-sm"></i>
                </button>
            </div>
        </div>
    </form>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <?php
                // Kritik stok seviyesindeki ürünleri say
                $sql = "SELECT COUNT(*) as count FROM materials m 
                        JOIN stock s ON m.id = s.material_id 
                        WHERE s.quantity <= m.min_stock";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                if ($row['count'] > 0) {
                    echo '<span class="badge badge-danger badge-counter">' . $row['count'] . '</span>';
                }
                ?>
            </a>
            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                    Stok Uyarıları
                </h6>
                <?php
                $sql = "SELECT m.name, s.quantity, m.min_stock, w.name as warehouse 
                        FROM materials m 
                        JOIN stock s ON m.id = s.material_id 
                        JOIN warehouses w ON s.warehouse_id = w.id
                        WHERE s.quantity <= m.min_stock 
                        LIMIT 5";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo '<a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3">
                                <div class="icon-circle bg-warning">
                                    <i class="fas fa-exclamation-triangle text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">' . $row['warehouse'] . '</div>
                                <span class="font-weight-bold">' . $row['name'] . ' - Stok: ' . $row['quantity'] . ' (Min: ' . $row['min_stock'] . ')</span>
                            </div>
                        </a>';
                }
                ?>
                <a class="dropdown-item text-center small text-gray-500" href="stock_alerts.php">Tüm Uyarıları Göster</a>
            </div>
        </li>

        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <?php 
                $unread_count = getUnreadMessageCount();
                if ($unread_count > 0):
                ?>
                <span class="badge badge-danger badge-counter"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                    Mesaj Merkezi
                </h6>
                <?php
                // Son 5 okunmamış mesajı getir
                $sql = "SELECT m.*, u.username, u.full_name 
                        FROM messages m
                        JOIN users u ON m.sender_id = u.id
                        WHERE m.receiver_id = ? AND m.is_read = 0 AND m.deleted_by_receiver = 0
                        ORDER BY m.created_at DESC LIMIT 5";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
                $messages = $stmt->get_result();
                
                if ($messages->num_rows > 0):
                    while ($message = $messages->fetch_assoc()):
                ?>
                <a class="dropdown-item d-flex align-items-center" href="chat.php">
                    <div class="dropdown-list-image mr-3">
                        <img class="rounded-circle" src="img/undraw_profile.svg" alt="<?php echo htmlspecialchars($message['full_name']); ?>">
                        <div class="status-indicator bg-success"></div>
                    </div>
                    <div class="font-weight-bold">
                        <div class="text-truncate"><?php echo htmlspecialchars($message['message']); ?></div>
                        <div class="small text-gray-500">
                            <?php echo htmlspecialchars($message['full_name']); ?> · 
                            <?php echo date('d.m.Y H:i', strtotime($message['created_at'])); ?>
                        </div>
                    </div>
                </a>
                <?php 
                    endwhile;
                else:
                ?>
                <div class="dropdown-item text-center small text-gray-500">Okunmamış mesajınız yok</div>
                <?php endif; ?>
                <a class="dropdown-item text-center small text-gray-500" href="chat.php">Tüm Mesajları Oku</a>
            </div>
        </li>

        <div class="topbar-divider d-none d-sm-block"></div>

        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo htmlspecialchars(getUserFullName()); ?></span>
                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
            </a>
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="profile.php">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profil
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Çıkış Yap
                </a>
            </div>
        </li>
    </ul>
</nav>
<!-- End of Topbar --> 
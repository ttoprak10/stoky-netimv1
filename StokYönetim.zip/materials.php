<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Oturum kontrolü
requireLogin();

// Malzeme ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_material'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $unit = mysqli_real_escape_string($conn, $_POST['unit']);
    $min_stock = (int)$_POST['min_stock'];

    $sql = "INSERT INTO materials (name, description, unit, min_stock) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $description, $unit, $min_stock);
    
    if ($stmt->execute()) {
        $success = "Malzeme başarıyla eklendi.";
    } else {
        $error = "Malzeme eklenirken bir hata oluştu.";
    }
    $stmt->close();
}

// Malzeme silme işlemi
if (isset($_GET['delete']) && $_SESSION['role'] === 'admin') {
    $id = (int)$_GET['delete'];
    
    $sql = "DELETE FROM materials WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $success = "Malzeme başarıyla silindi.";
    } else {
        $error = "Malzeme silinirken bir hata oluştu.";
    }
    $stmt->close();
}

// Malzemeleri listele
$sql = "SELECT m.*, 
        COALESCE(SUM(s.quantity), 0) as total_stock,
        GROUP_CONCAT(DISTINCT CONCAT(w.name, ': ', s.quantity) SEPARATOR ', ') as stock_details
        FROM materials m 
        LEFT JOIN stock s ON m.id = s.material_id 
        LEFT JOIN warehouses w ON s.warehouse_id = w.id 
        GROUP BY m.id 
        ORDER BY m.name";
$result = $conn->query($sql);

// Hata ayıklama
echo "<!-- Debug bilgileri:
Bağlantı durumu: " . ($conn->connect_error ? $conn->connect_error : "Başarılı") . "
SQL sorgusu: " . $sql . "
Hata (varsa): " . $conn->error . "
Sonuç: " . ($result ? "Başarılı" : "Başarısız") . "
Kayıt sayısı: " . ($result ? $result->num_rows : "0") . "
-->";

if (!$result) {
    die("Veritabanı hatası: " . $conn->error);
}

// Sonuç kümesinde kayıt var mı kontrol et
if ($result->num_rows === 0) {
    $warning = "Henüz hiç malzeme eklenmemiş.";
}

// DataTables için veri hazırlığı
$materials_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $materials_data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Malzemeler - Stok Takip Sistemi</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-2 text-gray-800">Malzemeler</h1>
                    
                    <?php if (isset($success)): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <!-- Malzeme Ekleme Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Yeni Malzeme Ekle</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label>Malzeme Adı</label>
                                        <input type="text" class="form-control" name="name" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label>Birim</label>
                                        <input type="text" class="form-control" name="unit" required>
                                    </div>
                                    <div class="form-group col-md-3">
                                        <label>Minimum Stok</label>
                                        <input type="number" class="form-control" name="min_stock" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Açıklama</label>
                                    <textarea class="form-control" name="description" rows="3"></textarea>
                                </div>
                                <button type="submit" name="add_material" class="btn btn-primary">Malzeme Ekle</button>
                            </form>
                        </div>
                    </div>

                    <!-- Malzeme Listesi Kartı -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Malzeme Listesi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Malzeme Adı</th>
                                            <th>Birim</th>
                                            <th>Minimum Stok</th>
                                            <th>Toplam Stok</th>
                                            <th>Stok Detayları</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($materials_data as $row): ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['unit']); ?></td>
                                            <td><?php echo $row['min_stock']; ?></td>
                                            <td>
                                                <?php 
                                                echo $row['total_stock'];
                                                if ($row['total_stock'] < $row['min_stock']) {
                                                    echo ' <span class="badge badge-danger">Kritik Stok!</span>';
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo $row['stock_details'] ? htmlspecialchars($row['stock_details']) : '<em>Stok yok</em>'; ?></td>
                                            <td>
                                                <a href="edit_material.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                                <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu malzemeyi silmek istediğinize emin misiniz? Bu işlem geri alınamaz!')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Turkish.json"
                }
            });
        });
    </script>
</body>
</html> 